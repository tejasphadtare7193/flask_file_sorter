from flask import Flask, render_template,request
import os
import datetime
import distutils.file_util
import shutil
import time

app = Flask(__name__)

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/thankyou.html',methods = ['POST'])
def ty():
    inputfilepath = request.form['inpath']
    outputfilepath = request.form['outpath']
    sort_message = filesort(inputfilepath,outputfilepath)

    return render_template('thankyou.html',sort_message = sort_message)

def filesort(inpath,outpath):
#Checking for '/' at the end
    if '/' in outpath[-1]:
        pass
    else:
        outpath = outpath + '/'
    if '/' in inpath[-1]:
        pass
    else:
        slash_inpath = inpath + '/'

    in_dir_list = os.listdir(inpath)
#Creating folders as per the file name format
    if len(in_dir_list) != 0:
        message = "Files have been sorted successfully..Thank You!!!"
        file_one = in_dir_list[0]
        file_spltname_ls = file_one.split('_')
        project_name = file_spltname_ls[0]
        shot_name = file_spltname_ls[1]
        file_dot_split = file_spltname_ls[2].split('.')
        task_name = file_dot_split[0]
        opath = os.path.join(outpath,project_name)
        try:
            os.mkdir(opath)
        except FileExistsError:
            message = "Folder {} already exists".format(opath)
        x = datetime.datetime.now()
        date_fol = x.strftime("%d"+"_"+"%b"+"_"+"%Y")
        dpath = os.path.join(opath,date_fol)
        try:
            os.mkdir(dpath)
        except FileExistsError:
            message = "Folder {} already exists".format(dpath)
        prjt_shot_nam = project_name +'_'+ shot_name
        ppath = os.path.join(dpath,prjt_shot_nam)
        try:
            os.mkdir(ppath)
        except FileExistsError:
            message = "Folder {} already exists".format(ppath)
        tpath = os.path.join(ppath,task_name)
        try:
            os.mkdir(tpath)
        except FileExistsError:
            message = "Folder {} already exists".format(tpath)
        tpath = os.path.join(ppath,task_name)
        all_ext_ls = []
        for file in in_dir_list:
            ext_name_ls = file.split('.')
            ext_name = ext_name_ls[-1]
            all_ext_ls.append(ext_name)

        all_ext_set = set(all_ext_ls)
        for ext in all_ext_set:
            patt = tpath +'/'+ ext.upper()
            try:
                os.mkdir(patt)
            except FileExistsError:
                message = "Folder {} already exists".format(patt)
    ##Moving file from source to destination
        for ext in all_ext_set:
             for file_ext in in_dir_list:
                      if ext in file_ext:
                          dest_task_path = tpath +'/'+ext
                          scr = slash_inpath + file_ext
                          try:
                              shutil.move(scr, dest_task_path)
                          except shutil.Error:
                              message = "Move failed!!! Folder {} already exists".format(dest_task_path)
    else:
        message = "File sorting Failed..Input Directory is empty!!!"
    return message
if __name__ == "__main__":
    app.run(debug=True)
